#ifndef _gpio_H_
#define _gpio_H_

#include "DEBUG.h"


UINT8 CH559GPIODrivCap(UINT8 Port,UINT8 Cap);
UINT8 CH559GPIOModeSelt(UINT8 Port,UINT8 Mode,UINT8 PinNum);
void CH559P4Mode( );


#endif
