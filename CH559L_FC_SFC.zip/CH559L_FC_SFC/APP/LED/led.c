#include "led.h"


#define Player1_led_all_ON  { P4_OUT = 0; P2 &= 0xf0; P3 &= 0x7f;}
#define Player1_led_all_OFF { P4_OUT = 0xff; P2 |= 0x0f; P3 |= 0x80;}

#define Player2_led_all_ON  { P0 &= 0x01; P1 &= 0xef; P2 &= 0xcf;}
#define Player2_led_all_OFF { P0 |= 0xfe; P1 |= 0x10; P2 |= 0x30;}


/* �ֱ�led��ʼ�� */
void LED_Init(void)
{
	
	/**/
//	CH559GPIOModeSelt(2,6,0);
//	CH559GPIOModeSelt(2,6,1);
//	CH559GPIOModeSelt(2,6,2);
//	CH559GPIOModeSelt(2,6,3);
	
	
	P3_DIR = 0xff;
	P3_PU = 0xff;
//	CH559GPIOModeSelt(3,6,7);
	
	P4_DIR |= 0xff;                                            //��1����Ϊ���
	P4_PU |= 0xff;
//	CH559P4Mode();
	
	/**/
	P0_DIR = 0xff;
	P0_PU = 0xff;
	
//	CH559GPIOModeSelt(0,6,0);
//	CH559GPIOModeSelt(0,6,1);
//	CH559GPIOModeSelt(0,6,2);
//	CH559GPIOModeSelt(0,6,3);
//	CH559GPIOModeSelt(0,6,4);
//	CH559GPIOModeSelt(0,6,5);
//	CH559GPIOModeSelt(0,6,6);
//	CH559GPIOModeSelt(0,6,7);
	
	
	P2_DIR = 0xff;
	P2_PU = 0xff;
//	CH559GPIOModeSelt(2,6,4);
//	CH559GPIOModeSelt(2,6,5);
	
	P1_IE &= 0xf7;	//P1^3 ADC
	PORT_CFG &= 0xfd;
	P1_DIR = 0xf7;
	P1_PU = 0xf7;
	P1_IE &= 0xf7;	//P1^3 ADC
//	CH559GPIOModeSelt(1,6,4);
}



void Player_LED_ALL_ON(UINT8 num)
{	
	switch(num)
	{
		case 1:	Player1_led_all_ON;
			break;
		case 2:	Player2_led_all_ON;
			break;
		default:
			break;
	}
}

void Player_LED_ALL_OFF(UINT8 num)
{	
	switch(num)
	{
		case 1:	Player1_led_all_OFF;
			break;
		case 2:	Player2_led_all_OFF;
			break;
		default:
			break;
	}
}


