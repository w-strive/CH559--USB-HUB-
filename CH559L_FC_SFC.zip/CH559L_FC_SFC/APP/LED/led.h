#ifndef _led_H_
#define _led_H_

#include "gpio.h"


/* �������һ����LED */
sbit P1_Up = P4_OUT^3;
sbit P1_Down = P4_OUT^7;
sbit P1_Left = P3^7;
sbit P1_Right = P4_OUT^2;

sbit P1_Select = P4_OUT^1;
sbit P1_Start = P4_OUT^0;

sbit P1_A = P2^2;
sbit P1_B = P2^3;
sbit P1_X = P2^1;
sbit P1_Y = P2^0;


/* ������Ҷ�����LED */
sbit P2_Up = P2^5;
sbit P2_Down = P0^6;
sbit P2_Left = P2^4;
sbit P2_Right = P0^7;

sbit P2_Select = P0^5;
sbit P2_Start = P0^4;

sbit P2_A = P0^1;
sbit P2_B = P1^4;
sbit P2_X = P0^2;
sbit P2_Y = P0^3;





/* ���һ */
#define P1_Up_ON { P1_Up = 0; P1_Down = 1; }
#define P1_Down_ON { P1_Up = 1; P1_Down = 0; }
#define P1_UpDown_ON { P1_Up = 0; P1_Down = 0; }
#define P1_UpDown_OFF { P1_Up = 1; P1_Down = 1; }

#define P1_Left_ON { P1_Left = 0; P1_Right = 1; }
#define P1_Right_ON { P1_Left = 1; P1_Right = 0; }
#define P1_LeftRight_ON { P1_Left = 0; P1_Right = 0; }
#define P1_LeftRight_OFF { P1_Left = 1; P1_Right = 1; }

#define P1_A_ON { P1_A = 0;}
#define P1_B_ON { P1_B = 0;}
#define P1_X_ON { P1_X = 0;}
#define P1_Y_ON { P1_Y = 0;}

#define P1_A_OFF { P1_A = 1;}
#define P1_B_OFF { P1_B = 1;}
#define P1_X_OFF { P1_X = 1;}
#define P1_Y_OFF { P1_Y = 1;}

#define P1_select_ON { P1_Select = 0;}
#define P1_select_OFF { P1_Select = 1;}
#define P1_Start_ON { P1_Start = 0;}
#define P1_Start_OFF { P1_Start = 1;}

#define P1_L1_ON {P1_UpDown_ON; P1_LeftRight_ON;}
#define P1_L1_OFF {P1_UpDown_OFF; P1_LeftRight_OFF;}

#define P1_L2_ON {}
#define P1_L2_OFF {}

#define P1_R1_ON {P1_A_ON; P1_B_ON; P1_X_ON; P1_Y_ON;}
#define P1_R1_OFF {P1_A_OFF; P1_B_OFF; P1_X_OFF; P1_Y_OFF;}

#define P1_R2_ON {}
#define P1_R2_OFF {}


/* ��Ҷ� */
#define P2_Up_ON { P2_Up = 0; P2_Down = 1; }
#define P2_Down_ON { P2_Up = 1; P2_Down = 0; }
#define P2_UpDown_ON { P2_Up = 0; P2_Down = 0; }
#define P2_UpDown_OFF { P2_Up = 1; P2_Down = 1; }

#define P2_Left_ON { P2_Left = 0; P2_Right = 1; }
#define P2_Right_ON { P2_Left = 1; P2_Right = 0; }
#define P2_LeftRight_ON { P2_Left = 0; P2_Right = 0; }
#define P2_LeftRight_OFF { P2_Left = 1; P2_Right = 1; }

#define P2_A_ON { P2_A = 0;}
#define P2_B_ON { P2_B = 0;}
#define P2_X_ON { P2_X = 0;}
#define P2_Y_ON { P2_Y = 0;}

#define P2_A_OFF { P2_A = 1;}
#define P2_B_OFF { P2_B = 1;}
#define P2_X_OFF { P2_X = 1;}
#define P2_Y_OFF { P2_Y = 1;}

#define P2_select_ON { P2_Select = 0;}
#define P2_select_OFF { P2_Select = 1;}
#define P2_Start_ON { P2_Start = 0;}
#define P2_Start_OFF { P2_Start = 1;}

#define P2_L1_ON {P2_UpDown_ON; P2_LeftRight_ON;}
#define P2_L1_OFF {P2_UpDown_OFF; P2_LeftRight_OFF;}

#define P2_L2_ON {}
#define P2_L2_OFF {}

#define P2_R1_ON {P2_A_ON; P2_B_ON; P2_X_ON; P2_Y_ON;}
#define P2_R1_OFF {P2_A_OFF; P2_B_OFF; P2_X_OFF; P2_Y_OFF;}

#define P2_R2_ON {}
#define P2_R2_OFF {}



void LED_Init(void);
void Player_LED_ALL_ON(UINT8 num);
void Player_LED_ALL_OFF(UINT8 num);

#endif
