#ifndef _hc_06_H_
#define _hc_06_H_

#include "DEBUG.h"


void CH559UART1Init(UINT8 DIV,UINT8 mode,UINT8 pin);
void CH559UART1SendByte(UINT8 SendDat);

#endif
