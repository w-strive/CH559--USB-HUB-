#ifndef _time_H_
#define _time_H_

#include "DEBUG.h"
#include "led.h"

void Time0_Init(void);



#endif
