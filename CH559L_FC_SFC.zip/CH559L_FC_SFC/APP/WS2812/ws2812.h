#ifndef _ws2812_H_
#define _ws2812_H_


#include "DEBUG.h"



void WS2812_SPI0_Host_Init(void);
void WS2812_SPI0_Write(UINT8 dat1,UINT8 dat2,UINT8 dat3);



#endif
